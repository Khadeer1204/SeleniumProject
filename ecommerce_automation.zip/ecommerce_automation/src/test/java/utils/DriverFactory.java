package utils;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class DriverFactory {
 private static final ThreadLocal<WebDriver> driver = new ThreadLocal<>();

 
 public static void setupDriver() {
     WebDriverManager.chromedriver().setup();
     WebDriver webDriver = new ChromeDriver();
     driver.set(webDriver);
     driver.get().manage().window().maximize();
 }

 /** Gets the current WebDriver instance. */
 public static WebDriver getDriver() {
     return driver.get();
 }

 /** Closes the browser and removes the driver instance. */
 public static void quitDriver() {
     if (driver.get() != null) {
         driver.get().quit();
         driver.remove();
     }
 }
}
