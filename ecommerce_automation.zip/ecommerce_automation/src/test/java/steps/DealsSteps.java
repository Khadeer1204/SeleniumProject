package steps;

import pages.HomePage;
import pages.DealsPage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import utils.DriverFactory;
 
public class DealsSteps {
    private WebDriver driver = DriverFactory.getDriver();
    private HomePage homePage = new HomePage(driver);
    private DealsPage dealsPage = new DealsPage(driver);
    private String savedProductName; // To save product name across steps
   
    @When("the user clicks on the {string} link")
    public void userClicksOnLink(String linkName) {
        if (linkName.equals("Today's Deals")) {
            homePage.clickTodayDeals();
            Hooks.currentScenario.log("Successfully clicked the '" + linkName + "' navigation link."); 
        }
    }
 
    @Then("the page title should contain {string}")
    public void assertPageTitleContains(String expectedText) {
        String actualTitle = driver.getTitle();
        Assert.assertTrue("Page title does not contain expected text: " + expectedText,
                          actualTitle.contains(expectedText));
        Hooks.currentScenario.log("Assertion Passed: Deals Page title contains '" + expectedText + "'. Title: " + actualTitle); 
    }
 
    @And("the user clicks on the first item in the Today's Deals section")
    public void userClicksOnFirstDealItem() {
        savedProductName = dealsPage.clickNthDealAndGetTitle(1);
        Hooks.currentScenario.log("Action: Clicked the **first deal** and landed on product page. Expected product name stored: **" + savedProductName + "**"); 
    }
 
    @Then("the user asserts the product name on the product page")
    public void assertProductName() {
        String actualProductName = dealsPage.getProductTitle();
        Assert.assertEquals("Product name validation failed", savedProductName, actualProductName);
        Hooks.currentScenario.log("Assertion Passed: Product name validated. Expected and Actual name: **" + actualProductName + "**"); 
    }
 
    @When("the user navigates back to the Deals Page")
    public void userNavigatesBack() {
        driver.navigate().back();
        Hooks.currentScenario.log("Navigated back to the Deals Page."); // 🌟 LOG ADDED 🌟
    }
    
    @And("the user clicks on the second item in the Today's Deals section")
    public void userClicksOnSecondDealItem() {
        savedProductName = dealsPage.clickNthDealAndGetTitle(2);
        Hooks.currentScenario.log("Action: Clicked the **second deal** and landed on product page. Expected product name stored: **" + savedProductName + "**"); 
    }
}