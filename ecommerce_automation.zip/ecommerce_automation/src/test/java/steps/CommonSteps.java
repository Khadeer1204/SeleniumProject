package steps;
 
import pages.HomePage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.And;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import utils.DriverFactory;
 
public class CommonSteps {
    private WebDriver driver = DriverFactory.getDriver();
    private HomePage homePage = new HomePage(driver);
 
    @Given("the user opens the browser and navigates to {string}")
    public void userOpensBrowserAndNavigates(String url) {
        homePage.navigateTo(url);
        Hooks.currentScenario.log("Navigated to the Amazon homepage: " + url); 
    }
 
    @Then("the page title should be {string}")
    public void assertPageTitle(String expectedTitle) {
        String actualTitle = driver.getTitle();
        Assert.assertEquals("Page title mismatch!", expectedTitle, actualTitle);
        Hooks.currentScenario.log("Assertion Passed: Page title is correctly validated as: '" + actualTitle + "'"); 
    }
 
    @And("the current URL should contain {string}")
    public void assertURLContains(String expectedText) {
        String actualUrl = driver.getCurrentUrl();
        Assert.assertTrue("URL does not contain expected text!", actualUrl.contains(expectedText));
        Hooks.currentScenario.log("Assertion Passed: Current URL contains '" + expectedText + "'. Actual URL: " + actualUrl); 
    }
    
    @And("the user closes the browser")
    public void userClosesTheBrowser() {
        Hooks.currentScenario.log("Browser closing via @After hook.");
    }
}