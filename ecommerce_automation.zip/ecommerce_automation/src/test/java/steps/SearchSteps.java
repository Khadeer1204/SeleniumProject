// Path: src/test/java/com/amazon/steps/SearchSteps.java (UPDATED)
 
package steps;
 
import pages.HomePage;
import pages.SearchResultPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import utils.DriverFactory;
 
public class SearchSteps {
    private WebDriver driver = DriverFactory.getDriver();
    private HomePage homePage = new HomePage(driver);
    private SearchResultPage searchResultPage = new SearchResultPage(driver);
 
    @When("the user searches for {string}")
    public void userSearchesFor(String searchItem) {
        homePage.searchForProduct(searchItem);
        Hooks.currentScenario.log("Action: Performed search for item: **" + searchItem + "**"); 
    }
 
    @Then("the search result title should contain {string}")
    public void assertSearchResultTitle(String searchItem) {
        String actualTitle = searchResultPage.getPageTitle();
        Assert.assertTrue("Search result title mismatch for: " + searchItem, 
                          actualTitle.toLowerCase().contains(searchItem.toLowerCase()));
        Hooks.currentScenario.log("Assertion Passed: Search result title validates the item: **" + searchItem + "**. Title: " + actualTitle);
    }
}
 