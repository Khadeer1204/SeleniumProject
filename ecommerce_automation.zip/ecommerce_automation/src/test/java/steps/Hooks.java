package steps;
 
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import utils.DriverFactory;
 
public class Hooks {
    
    // Static field to hold the current Scenario object
    public static Scenario currentScenario; 
 
    @Before
    public void setup(Scenario scenario) { 
        currentScenario = scenario; // Store the scenario object
        DriverFactory.setupDriver();
    }
 
    @After
    public void teardown(Scenario scenario) {
        WebDriver driver = DriverFactory.getDriver();
        
        // Attach screenshot on failure
        if (scenario.isFailed() && driver != null) {
            final byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
            scenario.attach(screenshot, "image/png", "Screenshot on failure");
        }
 
        DriverFactory.quitDriver();
        currentScenario = null; // Clear after scenario completion
    }
}