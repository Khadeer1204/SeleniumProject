package pages;
 
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
 
public class HomePage {
    private WebDriver driver;
    private WebDriverWait wait;
    
    // Locators
    private final By todayDealsLink = By.xpath("//a[text()=\"Today's Deals\"]");
    private final By searchBox = By.id("twotabsearchtextbox");
    private final By searchButton = By.id("nav-search-submit-button");
 
    public HomePage(WebDriver driver) {
    	  this.driver = driver;
          this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }
 
    // Actions
    public void navigateTo(String url) {
        driver.get(url);
    }
    public void clickTodayDeals() {
       
    	 wait.until(ExpectedConditions.elementToBeClickable(todayDealsLink)).click();
    }
    
 
    public void searchForProduct(String item) {
        driver.findElement(searchBox).sendKeys(item);
        driver.findElement(searchButton).click();
    }
}
 