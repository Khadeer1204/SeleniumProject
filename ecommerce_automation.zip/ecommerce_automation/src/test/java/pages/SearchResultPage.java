package pages;
 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
 
public class SearchResultPage {
    private WebDriver driver;
    private WebDriverWait wait;
 
    public SearchResultPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }
 
    /** Gets the title of the current page (which should be the search result title). */
    public String getPageTitle() {
        return driver.getTitle();
    }
}
 