// Path: src/test/java/com/amazon/pages/DealsPage.java
 
package pages;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
 
public class DealsPage {
    private WebDriver driver;
    private WebDriverWait wait;
 
    // Locators
    private final By dealCards = By.xpath("\"//div[@data-test-index='0']\""); 
    private final By productTitle = By.id("productTitle");
 
    public DealsPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15)); 
    }
 
    /** Clicks on the N-th deal card and returns the product title from the detail page. */
    public String clickNthDealAndGetTitle(int index) {
        // 1. Wait until at least one deal card is visible
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(dealCards));
        
        // Find the Nth deal card link and wait for it to be clickable
        WebElement dealLink = wait.until(ExpectedConditions.elementToBeClickable(
            driver.findElements(dealCards).get(index - 1).findElement(By.xpath(".//a"))
        ));
        
        dealLink.click();
        
        // 2. Wait for the product detail page title to be visible before extracting text
        wait.until(ExpectedConditions.visibilityOfElementLocated(productTitle));
        return driver.findElement(productTitle).getText().trim();
    }
 
    /** Gets the product title from the current detail page. */
    public String getProductTitle() {
        // Wait for the product title to be visible (ensures page is fully loaded)
        wait.until(ExpectedConditions.visibilityOfElementLocated(productTitle));
        return driver.findElement(productTitle).getText().trim();
    }
}
 