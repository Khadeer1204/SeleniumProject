package scenarios;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LocatorsScenario {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver = new ChromeDriver();
   	  try {
	      driver.get("https://the-internet.herokuapp.com/");
	      
	      // By.linkText
          WebElement abTestLink = driver.findElement(By.linkText("A/B Testing"));
          System.out.println("Link Text: " + abTestLink.getText());
          
          // By.partialLinkText
          WebElement formAuthLink = driver.findElement(By.partialLinkText("Form"));
          System.out.println("Partial Link: " + formAuthLink.getText());

          // By.id (example: login page)
          formAuthLink.click();
          WebElement username = driver.findElement(By.id("username"));
          username.sendKeys("tomsmith");

          // By.name
          WebElement password = driver.findElement(By.name("password"));
          password.sendKeys("SuperSecretPassword!");

          // By.className
          WebElement loginBtn = driver.findElement(By.className("radius"));
          System.out.println("Button text: " + loginBtn.getText());
          loginBtn.click();

          // By.tagName
          List<WebElement> allParagraphs = driver.findElements(By.tagName("p"));
          System.out.println("Total paragraphs: " + allParagraphs.size());

          // WebElement methods
          WebElement flashMsg = driver.findElement(By.id("flash"));
          System.out.println("Flash message: " + flashMsg.getText());
          System.out.println("Displayed? " + flashMsg.isDisplayed());


   	  } finally {
   		  driver.quit();
   	  }
	}

}
