package scenarios;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class NavigationaScenario {

	public static void main(String[] args) throws InterruptedException {
	

        WebDriver driver = new EdgeDriver();              
         
          try {
    	 // Open a site
    	   driver.get("https://the-internet.herokuapp.com/");
    	 // Maximizing the window
          driver.manage().window().maximize();
    	  // Print the Title of the current page.
    	  System.out.println("Title: "+ driver.getTitle());
    	  // Print the URL of the Current page.
    	  System.out.println("URL: "+ driver.getCurrentUrl());
    	  
    	  // Navigation methods
    	  
    	  Thread.sleep(2000);
    	  // Navigate to particular Url
    	  driver.navigate().to("https://www.selenium.dev/");
    	  
    	  Thread.sleep(2000);
         // Navigate back to before page	  
    	  driver.navigate().back();
    	  
    	  Thread.sleep(2000);
    	  // Navigate to previous(forward) page
    	  driver.navigate().forward();
    	  
    	  Thread.sleep(2000);
    	  // To refresh the page
    	  driver.navigate().refresh();
    	  
    	  // Page source length
    	  System.out.println("Page Source length: "+ driver.getPageSource().length());
          }
          finally{
     
    	  driver.quit();
          }
	}

}
