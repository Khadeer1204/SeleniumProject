package scenarios;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class ActionsScenarioMain {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
         WebDriver driver = new ChromeDriver();
         driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
          try {
        	  driver.get("https://the-internet.herokuapp.com/");

              Actions actions = new Actions(driver);
               
              // Hover over element
              WebElement hoverLink = driver.findElement(By.linkText("Hovers"));
           actions.moveToElement(hoverLink).perform();
           hoverLink.click();
           
           // Hover over image
          WebElement image = driver.findElement(By.xpath("(//div[@class='figure'])[1]")); 
          actions.moveToElement(image).perform();
          Thread.sleep(2000);
          
//         Perform action that triggers alert
//          driver.findElement(By.id("trigger-alert")).click();
//
//           Switch to alert
//          Alert alert = driver.switchTo().alert();
//
//           Read text
//          System.out.println("Alert says: " + alert.getText());
//
//           Accept or dismiss
//          alert.accept();   // or alert.dismiss();


          // Right click ( context click)
          driver.navigate().to("https://the-internet.herokuapp.com/context_menu");
          Thread.sleep(2000);
          WebElement box = driver.findElement(By.id("hot-spot"));
          actions.contextClick(box).perform();
          Alert alert = driver.switchTo().alert();
          alert.accept();
          
       // Double click (demo site)
          driver.navigate().to("https://demoqa.com/buttons");
          WebElement doubleClickBtn = driver.findElement(By.id("doubleClickBtn"));
          actions.doubleClick(doubleClickBtn).perform();

          // Drag and Drop
          driver.navigate().to("https://demoqa.com/droppable");
          WebElement source = driver.findElement(By.id("draggable"));
          WebElement target = driver.findElement(By.id("droppable"));
          actions.dragAndDrop(source, target).perform();

          // Keyboard actions
          driver.navigate().to("https://the-internet.herokuapp.com/key_presses");
          actions.sendKeys(Keys.ENTER).perform();
          actions.sendKeys(Keys.ARROW_DOWN).perform();

          // Scroll
          driver.navigate().to("https://the-internet.herokuapp.com/");
          WebElement footer = driver.findElement(By.xpath("//div[@id='page-footer']"));
          actions.scrollToElement(footer).perform();

          
        	  
          }finally {
        	  driver.quit();
          }
	}

}
